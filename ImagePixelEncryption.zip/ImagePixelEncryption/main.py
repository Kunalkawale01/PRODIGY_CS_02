
from crypto import encrypt_image, decrypt_image

def menu():
    print("="*45)
    print("   IMAGE PIXEL ENCRYPTION TOOL")
    print("="*45)
    print("1. Encrypt Image")
    print("2. Decrypt Image")
    print("3. Exit")

def main():
    while True:
        menu()
        choice = input("Choose (1/2/3): ").strip()

        if choice == "1":
            path = input("Enter image path: ").strip()
            key = int(input("Enter numeric key (0-255): "))
            encrypt_image(path, key)
            print("Encrypted image saved as encrypted.png")

        elif choice == "2":
            path = input("Enter encrypted image path: ").strip()
            key = int(input("Enter numeric key (0-255): "))
            decrypt_image(path, key)
            print("Decrypted image saved as decrypted.png")

        elif choice == "3":
            print("Exiting...")
            break
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()
