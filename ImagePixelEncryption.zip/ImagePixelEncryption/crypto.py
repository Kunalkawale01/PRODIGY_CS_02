
from PIL import Image

def _process(image_path, key, out_name):
    img = Image.open(image_path).convert("RGB")
    pixels = img.load()

    for x in range(img.width):
        for y in range(img.height):
            r, g, b = pixels[x, y]
            pixels[x, y] = (
                r ^ key,
                g ^ key,
                b ^ key
            )

    img.save(out_name)

def encrypt_image(image_path, key):
    _process(image_path, key, "encrypted.png")

def decrypt_image(image_path, key):
    _process(image_path, key, "decrypted.png")
