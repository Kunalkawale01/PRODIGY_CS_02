
# Pixel Manipulation Image Encryption

## Description
A simple Python project that encrypts and decrypts images using pixel manipulation.
Each pixel's RGB values are XOR-ed with a numeric key, making encryption reversible.

## How It Works
- XOR operation applied to each pixel
- Same key decrypts the image
- Supports JPG/PNG images

## How to Run
1. Install Python 3
2. Install dependencies:
   pip install pillow
3. Run:
   python main.py

## Output
- encrypted.png
- decrypted.png
